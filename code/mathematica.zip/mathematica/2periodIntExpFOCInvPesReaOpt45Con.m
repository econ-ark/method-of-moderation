(* ::Package:: *)

(* 2periodIntExpFOCInvPesReaOpt45Con.m *)
(* Constrained PesReaOpt solution *)
<<prepareIntExpFOCInvPesReaOpt45.m;

<<setup_params_2period.m;
TimesToNest=20;GridLength=5;<<setup_grids_expMult.m;
<<setup_shocks.m;
<<setup_PerfectForesightSolution45.m;
<<setup_lastperiod.m;
<<setup_lastperiod_PesReaOpt.m;
<<setup_lastperiod_PesReaOpt45.m;
<<setup_lastperiod_PesReaOpt45Con.m;

SolveAnotherPeriod;
