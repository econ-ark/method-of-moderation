(* ::Package:: *)

(* 2periodIntExpFOCInvPesReaOpt45.m *)
(* Use the 'method of moderation' fact:
Pessimist < Realist < Optimist (PesReaOpt)
and 
Realist < 45 Degree Line (45)
*)
<<prepareIntExpFOCInvPesReaOpt45.m;

<<setup_params_2period.m;
TimesToNest=20;GridLength=5;<<setup_grids_expMult.m;
<<setup_shocks.m;
<<setup_PerfectForesightSolution45.m;
<<setup_lastperiod.m;
<<setup_lastperiod_PesReaOpt.m;
<<setup_lastperiod_PesReaOpt45.m;

SolveAnotherPeriod;
