(* ::Package:: *)

(* 2PeriodInt.m - Interpolate \[ScriptC] and \[ScriptV] functions *)
<<setup_everything.m;
<<prepareInt.m;

SolveAnotherPeriod;
