(* ::Package:: *)

(* 2periodIntExpFOCInv.m *)
<<setup_everything.m;
\[GothicC]FuncLife = { Indeterminate & }; (* Consumed function meaningless in last period of life *)

<<prepareIntExpFOCInv.m;

SolveAnotherPeriod;
