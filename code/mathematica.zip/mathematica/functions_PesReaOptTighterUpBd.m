(* ::Package:: *)

(* ::Subsection:: *)
(*Consumption function;*)


ClearAll[\[Chi]Hi];
\[Chi]Hi[\[Mu]_,PeriodsUntilT_] := \[Chi]FuncLifeHi[[PeriodsUntilT+1]][\[Mu]];
ClearAll[\[Chi]\[Mu]Hi];
\[Chi]\[Mu]Hi[\[Mu]_,PeriodsUntilT_] := \[Chi]FuncLifeHi[[PeriodsUntilT+1]]'[\[Mu]];

ClearAll[\[Chi]Lo];
\[Chi]Lo[\[Mu]_,PeriodsUntilT_] := \[Chi]FuncLifeLo[[PeriodsUntilT+1]][\[Mu]];
ClearAll[\[Chi]\[Mu]Lo];
\[Chi]\[Mu]Lo[\[Mu]_,PeriodsUntilT_] := \[Chi]FuncLifeLo[[PeriodsUntilT+1]]'[\[Mu]];


\[ScriptC]Hi[mt_,PeriodsUntilT_]:= Block[{
  mLowerBoundt, mCuspt , \[FilledUpTriangle]mt, \[FilledUpTriangle]\[GothicH]t, \[Kappa]t, \[Kappa]Maxt, \[Mu]t, \[Mu]First, \[Chi]t, \[Chi]Lowert, \[Koppa]t, \[Koppa]Lowert, ctOptmst, ctPesmst, ctRealst},
  mLowerBoundt = \[GothicA]LowerBoundLife[[PeriodsUntilT+1]]; 
  mCuspt =mCuspLife[[PeriodsUntilT+1]];
  \[FilledUpTriangle]mt   = mt-mLowerBoundt;
  \[FilledUpTriangle]\[GothicH]t   = \[FilledUpTriangle]\[GothicH]AccessibleLife[[PeriodsUntilT+1]];
  \[Kappa]t    = \[Kappa]MinLife[[PeriodsUntilT+1]];
  \[Kappa]Maxt    = \[Kappa]MaxLife[[PeriodsUntilT+1]]; (* June 2012 KT added *)
  \[Mu]t = Log[\[FilledUpTriangle]mt];If[Chop[mt - mLowerBoundt]==0,\[Mu]t=-Infinity];
(*See Derivations.nb for derivations of formulas below *)
  ctOptmst = \[Kappa]t (\[FilledUpTriangle]mt+\[FilledUpTriangle]\[GothicH]t);
  ctPesmst = \[Kappa]t (\[FilledUpTriangle]mt);  
  \[Chi]t  = \[Chi]Hi[\[Mu]t,PeriodsUntilT]
; \[Koppa]t  =1/(1+Exp[\[Chi]t])
; ctRealst=ctOptmst-(ctOptmst-ctPesmst) \[Koppa]t
;
  Return[ctRealst]
];(*End Block*)

\[ScriptC]Lo[mt_,PeriodsUntilT_]:= Block[{
  mLowerBoundt, mCuspt , \[FilledUpTriangle]mt, \[FilledUpTriangle]\[GothicH]t, \[Kappa]t, \[Kappa]Maxt, \[Mu]t, \[Mu]First, \[Chi]t, \[Chi]Lowert, \[Koppa]t, \[Koppa]Lowert, ctOptmst, ctPesmst, ctRealst},
  mLowerBoundt = \[GothicA]LowerBoundLife[[PeriodsUntilT+1]]; 
  mCuspt =mCuspLife[[PeriodsUntilT+1]];
  \[FilledUpTriangle]mt   = mt-mLowerBoundt;
  \[FilledUpTriangle]\[GothicH]t   = \[FilledUpTriangle]\[GothicH]AccessibleLife[[PeriodsUntilT+1]];
  \[Kappa]t    = \[Kappa]MinLife[[PeriodsUntilT+1]];
  \[Kappa]Maxt    = \[Kappa]MaxLife[[PeriodsUntilT+1]]; (* June 2012 KT added *)
  \[Mu]t = Log[\[FilledUpTriangle]mt];If[Chop[mt - mLowerBoundt]==0,\[Mu]t=-Infinity];
(*See Derivations.nb for derivations of formulas below *)
  ctOptmst = \[Kappa]t (\[FilledUpTriangle]mt+\[FilledUpTriangle]\[GothicH]t);
  ctPesmst = \[Kappa]t (\[FilledUpTriangle]mt);  
  \[Chi]t  = \[Chi]Lo[\[Mu]t,PeriodsUntilT];
 \[Koppa]t  =1/(1+Exp[\[Chi]t]);
 ctRealst=\[Kappa]Maxt \[FilledUpTriangle]mt-(\[Kappa]Maxt \[FilledUpTriangle]mt-ctPesmst) \[Koppa]t; (* June 2012 KT fixed *)
  Return[ctRealst];
];(*End Block*)

\[ScriptC]Md[mt_,PeriodsUntilT_]:= Block[{
  ctRealst},
  ctRealst = \[ScriptC]FuncLifeMd[[PeriodsUntilT+1]][mt];
  Return[ctRealst];
];(*End Block*)


ClearAll[\[ScriptC], \[ScriptC]BeforeT, \[ScriptC]From\[Chi]];
\[ScriptC][mt_,PeriodsUntilT_] := If[PeriodsUntilT == 0
  ,(*then*) Return[mt]
  ,(*else*) \[ScriptC]BeforeT[mt,PeriodsUntilT]];
\[ScriptC]BeforeT[mt_,PeriodsUntilT_] := \[ScriptC]From\[Chi][mt,PeriodsUntilT];

(* Block[{cUnconstr},
  If[Constrained==False, Return[\[ScriptC]From\[Chi][mt,PeriodsUntilT]]];
  cUnconstr = \[ScriptC]From\[Chi][mt,PeriodsUntilT];
  If[cUnconstr > mt, Return[mt]]; (* If you want to consume more than m, too bad! *)
  Return[cUnconstr];
];*)

\[ScriptC]From\[Chi][mt_,PeriodsUntilT_]:= Block[{
  mLowerBoundt, mCuspt, \[FilledUpTriangle]mt, mHighestBelowmCuspt 
, mLowestAbovemCuspt, \[FilledUpTriangle]\[GothicH]t, \[Kappa]t, \[Kappa]Maxt, \[Mu]t, \[Mu]First, \[Chi]t, \[Koppa]t, ctOptmst, ctPesmst, ctRealst},
 
  mLowerBoundt = mLowerBoundLife[[PeriodsUntilT+1]]; 
  mCuspt =mCuspLife[[PeriodsUntilT+1]];
  mHighestBelowmCuspt = mHighestBelowmCuspLife[[PeriodsUntilT+1]];
  mLowestAbovemCuspt = mLowestAbovemCuspLife[[PeriodsUntilT+1]]; 

  \[FilledUpTriangle]mt   = mt-mLowerBoundt;
  \[FilledUpTriangle]\[GothicH]t   = \[FilledUpTriangle]\[GothicH]AccessibleLife[[PeriodsUntilT+1]];
  \[Kappa]t    = \[Kappa]MinLife[[PeriodsUntilT+1]];
  \[Kappa]Maxt    = \[Kappa]MaxLife[[PeriodsUntilT+1]]; (* June 2012 KT added *)
  \[Mu]t = Log[\[FilledUpTriangle]mt];If[Chop[mt - mLowerBoundt]==0,\[Mu]t=-Infinity];
(*See Derivations.nb for derivations of formulas below *)
  ctOptmst = \[Kappa]t (\[FilledUpTriangle]mt+\[FilledUpTriangle]\[GothicH]t);
  ctPesmst = \[Kappa]t (\[FilledUpTriangle]mt);  

  If[mt >= mLowestAbovemCuspt
(* if mt >= mLoestAbovemCuspt (lowest point above mCusp), use Hi func *)
, \[Chi]t  = \[Chi]Hi[\[Mu]t,PeriodsUntilT]
; \[Koppa]t  =1/(1+Exp[\[Chi]t])
; ctRealst=ctOptmst-(ctOptmst-ctPesmst) \[Koppa]t
];

(* if mHiestBelowmCuspt <= mt <mLowestAbovemCuspt , use Mid function *)
  If[And[mt < mLowestAbovemCuspt, mt >= mHighestBelowmCuspt]
(* then use Mid func *)
, ctRealst = \[ScriptC]FuncLifeMd[[PeriodsUntilT+1]][mt]
];

(* if mt <= mHighestBelowmCuspt, use Lo func *)
 If[mt < mHighestBelowmCuspt
, \[Chi]t  = \[Chi]Lo[\[Mu]t,PeriodsUntilT]
; \[Koppa]t  =1/(1+Exp[\[Chi]t])
; ctRealst=\[Kappa]Maxt \[FilledUpTriangle]mt-(\[Kappa]Maxt \[FilledUpTriangle]mt-ctPesmst) \[Koppa]t 
]; (* End If *)

  Return[ctRealst]
];(*End Block*)

\[ScriptC][mt_] := \[ScriptC][mt,Length[\[Beta]Life]-1]; (* Without lifeperiod argument, use most recently solved *)


\[Kappa]Hi[mt_,PeriodsUntilT_]:=Block[{mLowerBoundt, mCuspt, \[FilledUpTriangle]mt, \[FilledUpTriangle]\[GothicH]t, \[Kappa]t, \[Kappa]Maxt, \[Mu]t, \[Mu]First
, \[Chi]t, \[Chi]\[Mu]t, \[Koppa]t, \[Koppa]\[Mu]t, ctOptmst, ctPesmst, ctRealst, \[Kappa]tOptmst, \[Kappa]tPesmst, \[Kappa]tRealst},
  mLowerBoundt = \[GothicA]LowerBoundLife[[PeriodsUntilT+1]]; 
  mCuspt =mCuspLife[[PeriodsUntilT+1]];
  \[FilledUpTriangle]mt   = mt-mLowerBoundt;
  \[FilledUpTriangle]\[GothicH]t   = \[FilledUpTriangle]\[GothicH]AccessibleLife[[PeriodsUntilT+1]];
  \[Kappa]t    = \[Kappa]MinLife[[PeriodsUntilT+1]];
  \[Kappa]Maxt    = \[Kappa]MaxLife[[PeriodsUntilT+1]]; (* June 2012 KT added *)
  \[Mu]t = Log[\[FilledUpTriangle]mt];If[Chop[mt - mLowerBoundt]==0,\[Mu]t=-Infinity];
  ctOptmst = \[Kappa]t (\[FilledUpTriangle]mt+\[FilledUpTriangle]\[GothicH]t);
  ctPesmst = \[Kappa]t (\[FilledUpTriangle]mt); 
  \[Kappa]tOptmst = \[Kappa]t;
  \[Kappa]tPesmst = \[Kappa]t;
(*See Derivations.nb for derivations of formulas below *)
 
  \[Chi]t  = \[Chi]Hi[\[Mu]t,PeriodsUntilT];
  \[Chi]\[Mu]t = \[Chi]\[Mu]Hi[\[Mu]t,PeriodsUntilT];
  \[Koppa]t  =1/(1+Exp[\[Chi]t]); 
  \[Koppa]\[Mu]t = \[Chi]\[Mu]t (\[Koppa]t-1) \[Koppa]t; 
  ctRealst=ctOptmst-(ctOptmst-ctPesmst) \[Koppa]t; 
  \[Kappa]tRealst = \[Kappa]tOptmst-\[Koppa]\[Mu]t (ctOptmst-ctPesmst)/\[FilledUpTriangle]mt;
  Return[\[Kappa]tRealst]
];

\[Kappa]Lo[mt_,PeriodsUntilT_]:=Block[{mLowerBoundt, mCuspt, \[FilledUpTriangle]mt, \[FilledUpTriangle]\[GothicH]t, \[Kappa]t, \[Kappa]Maxt, \[Mu]t, \[Mu]First, \[Chi]t, \[Chi]\[Mu]t
, \[Koppa]t, \[Koppa]\[Mu]t, ctOptmst, ctPesmst, ctRealst, \[Kappa]tOptmst, \[Kappa]tPesmst, \[Kappa]tRealst},
  mLowerBoundt = \[GothicA]LowerBoundLife[[PeriodsUntilT+1]]; 
  mCuspt =mCuspLife[[PeriodsUntilT+1]];
  \[FilledUpTriangle]mt   = mt-mLowerBoundt;
  \[FilledUpTriangle]\[GothicH]t   = \[FilledUpTriangle]\[GothicH]AccessibleLife[[PeriodsUntilT+1]];
  \[Kappa]t    = \[Kappa]MinLife[[PeriodsUntilT+1]];
  \[Kappa]Maxt    = \[Kappa]MaxLife[[PeriodsUntilT+1]]; (* June 2012 KT added *)
  \[Mu]t = Log[\[FilledUpTriangle]mt];If[Chop[mt - mLowerBoundt]==0,\[Mu]t=-Infinity];
  ctOptmst = \[Kappa]t (\[FilledUpTriangle]mt+\[FilledUpTriangle]\[GothicH]t);
  ctPesmst = \[Kappa]t (\[FilledUpTriangle]mt); 
  \[Kappa]tOptmst = \[Kappa]t;
  \[Kappa]tPesmst = \[Kappa]t;
(*See Derivations.nb for derivations of formulas below *)
 
  \[Chi]t  = \[Chi]Lo[\[Mu]t,PeriodsUntilT];
  \[Chi]\[Mu]t = \[Chi]\[Mu]Lo[\[Mu]t,PeriodsUntilT];
  \[Koppa]t  =1/(1+Exp[\[Chi]t]);
  \[Koppa]\[Mu]t = \[Chi]\[Mu]t (\[Koppa]t-1) \[Koppa]t; 
  ctRealst=\[Kappa]Maxt \[FilledUpTriangle]mt- (\[Kappa]Maxt \[FilledUpTriangle]mt-ctPesmst) \[Koppa]t; (* June 2012 KT fixed *)
  \[Kappa]tRealst = ctRealst/\[FilledUpTriangle]mt-\[Koppa]\[Mu]t (\[Kappa]Maxt-\[Kappa]tOptmst);
  Return[\[Kappa]tRealst]
];

\[Kappa]Md[mt_,PeriodsUntilT_]:= Block[{
  \[Kappa]tRealst},
  \[Kappa]tRealst = \[ScriptC]FuncLifeMd[[PeriodsUntilT+1]]'[mt];
  Return[\[Kappa]tRealst];
];(*End Block*)


ClearAll[\[Kappa], \[Kappa]BeforeT, \[Kappa]From\[Chi]];
\[Kappa][mt_,PeriodsUntilT_] := If[PeriodsUntilT == 0,Return[1.]
, (*else*)\[Kappa]BeforeT[mt,PeriodsUntilT]];
\[Kappa]BeforeT[mt_,PeriodsUntilT_] := \[Kappa]From\[Chi][mt,PeriodsUntilT];

(*Block[{cUnconstr,\[Kappa]Unconstr},
  If[Constrained==False, Return[\[Kappa]From\[Chi][mt,PeriodsUntilT]]];
  cUnconstr = \[ScriptC]From\[Chi][mt,PeriodsUntilT];
  If[cUnconstr > mt,Return[1.]]; (* MPC is 1 if consumer is liquidity constrained *)
  Return[\[Kappa]From\[Chi][mt,PeriodsUntilT]]
];
*)
\[Kappa]From\[Chi][mt_,PeriodsUntilT_]:=Block[{mLowerBoundt,  mCuspt, \[FilledUpTriangle]mt, mHighestBelowmCuspt 
, mLowestAbovemCuspt, \[FilledUpTriangle]\[GothicH]t, \[Kappa]t, \[Kappa]Maxt, \[Mu]t, \[Mu]First, \[Chi]t, \[Chi]\[Mu]t
, \[Koppa]t, \[Koppa]\[Mu]t, ctOptmst, ctPesmst, ctRealst, \[Kappa]tOptmst, \[Kappa]tPesmst, \[Kappa]tRealst},
  mLowerBoundt = \[GothicA]LowerBoundLife[[PeriodsUntilT+1]]; 
  mCuspt =mCuspLife[[PeriodsUntilT+1]];
  \[FilledUpTriangle]mt   = mt-mLowerBoundt;
  mHighestBelowmCuspt = mHighestBelowmCuspLife[[PeriodsUntilT+1]];
  mLowestAbovemCuspt = mLowestAbovemCuspLife[[PeriodsUntilT+1]]; 
  \[FilledUpTriangle]\[GothicH]t   = \[FilledUpTriangle]\[GothicH]AccessibleLife[[PeriodsUntilT+1]];
  \[Kappa]t    = \[Kappa]MinLife[[PeriodsUntilT+1]];
  \[Kappa]Maxt    = \[Kappa]MaxLife[[PeriodsUntilT+1]];
  \[Mu]t = Log[\[FilledUpTriangle]mt];If[Chop[mt - mLowerBoundt]==0,\[Mu]t=-Infinity];
  ctOptmst = \[Kappa]t (\[FilledUpTriangle]mt+\[FilledUpTriangle]\[GothicH]t);
  ctPesmst = \[Kappa]t (\[FilledUpTriangle]mt);  
  \[Kappa]tOptmst = \[Kappa]t;
  \[Kappa]tPesmst = \[Kappa]t;
(*See Derivations.nb for derivations of formulas below *)
  If[mt>= mLowestAbovemCuspt
(* if mt >= mLoestAbovemCuspt (lowest point above mCusp), use Hi func *)
, \[Chi]t  = \[Chi]Hi[\[Mu]t,PeriodsUntilT]
; \[Chi]\[Mu]t = \[Chi]\[Mu]Hi[\[Mu]t,PeriodsUntilT]
; \[Koppa]t  =1/(1+Exp[\[Chi]t])
; \[Koppa]\[Mu]t = \[Chi]\[Mu]t (\[Koppa]t-1) \[Koppa]t
; ctRealst=ctOptmst-(ctOptmst-ctPesmst) \[Koppa]t
; \[Kappa]tRealst = \[Kappa]tOptmst-\[Koppa]\[Mu]t (ctOptmst-ctPesmst)/\[FilledUpTriangle]mt
;
];

(* if mHiestBelowmCuspt <= mt <mLowestAbovemCuspt , use Mid function *)
If[And[mt < mLowestAbovemCuspt, mt >= mHighestBelowmCuspt]
(* then use Mid func *)
, \[Kappa]tRealst = \[ScriptC]FuncLifeMd[[PeriodsUntilT+1]]'[mt]
];

(* if mt <= mHighestBelowmCuspt, use Lo func *)
 If[mt < mHighestBelowmCuspt
, \[Chi]t  = \[Chi]Lo[\[Mu]t,PeriodsUntilT]
; \[Chi]\[Mu]t = \[Chi]\[Mu]Lo[\[Mu]t,PeriodsUntilT]
; \[Koppa]t  =1/(1+Exp[\[Chi]t])
; \[Koppa]\[Mu]t = \[Chi]\[Mu]t (\[Koppa]t-1) \[Koppa]t
; ctRealst=\[Kappa]Maxt \[FilledUpTriangle]mt-(\[Kappa]Maxt \[FilledUpTriangle]mt-ctPesmst) \[Koppa]t
; \[Kappa]tRealst = ctRealst/\[FilledUpTriangle]mt-\[Koppa]\[Mu]t (\[Kappa]Maxt-\[Kappa]tOptmst)
;
];

  Return[\[Kappa]tRealst]
];

\[Kappa][mt_] := \[Kappa][mt,Length[\[Beta]Life]-1]; (* Without lifeperiod argument, use most recently solved *)


(* ::Subsection:: *)
(*Value function;*)


ClearAll[\[CapitalChi]Hi];
\[CapitalChi]Hi[\[Mu]_,PeriodsUntilT_] := \[CapitalChi]FuncLifeHi[[PeriodsUntilT+1]][\[Mu]];

ClearAll[\[CapitalChi]\[Mu]Hi];
\[CapitalChi]\[Mu]Hi[\[Mu]_,PeriodsUntilT_] := \[CapitalChi]FuncLifeHi[[PeriodsUntilT+1]]'[\[Mu]];

ClearAll[\[CapitalChi]Lo];
\[CapitalChi]Lo[\[Mu]_,PeriodsUntilT_] := \[CapitalChi]FuncLifeLo[[PeriodsUntilT+1]][\[Mu]];

ClearAll[\[CapitalChi]\[Mu]Lo];
\[CapitalChi]\[Mu]Lo[\[Mu]_,PeriodsUntilT_] := \[CapitalChi]FuncLifeLo[[PeriodsUntilT+1]]'[\[Mu]];


\[CapitalLambda]Hi[mt_,PeriodsUntilT_]:= Block[{
  mLowerBoundt, \[FilledUpTriangle]mt, \[FilledUpTriangle]\[GothicH]t, \[Kappa]t, \[Kappa]Maxt, \[Mu]t, \[CapitalChi]t, \[CapitalKoppa]t
, ctOptmst, ctPesmst, \[CapitalLambda]tTighterUpBd, \[CapitalLambda]tOptmst, \[CapitalLambda]tPesmst, \[CapitalLambda]tRealst, \[Mu]First, vSumt
, mCuspt, \[GothicV]OptmstCon0at, \[ScriptV]tOptmstCon, \[CapitalLambda]tOptmstCon},
  mLowerBoundt = mLowerBoundLife[[PeriodsUntilT+1]]; 
  mCuspt =mCuspLife[[PeriodsUntilT+1]];
(*
  \[GothicV]OptmstCon0at=\[GothicV]OptmstCon0aLife[[PeriodsUntilT+1]];
*)
vSumt=vSumLife[[PeriodsUntilT+1]];
  \[FilledUpTriangle]mt   = mt-mLowerBoundt;
  \[FilledUpTriangle]\[GothicH]t   = \[FilledUpTriangle]\[GothicH]AccessibleLife[[PeriodsUntilT+1]];
  \[Kappa]t    = \[Kappa]MinLife[[PeriodsUntilT+1]];
  \[Kappa]Maxt    = \[Kappa]MaxLife[[PeriodsUntilT+1]]; (* June 2012 KT added *)
  \[Mu]t = Log[\[FilledUpTriangle]mt];If[Chop[mt - mLowerBoundt]==0,\[Mu]t=-Infinity];
  ctOptmst = \[Kappa]t (\[FilledUpTriangle]mt+\[FilledUpTriangle]\[GothicH]t);
  ctPesmst = \[Kappa]t (\[FilledUpTriangle]mt); 
  \[CapitalLambda]tOptmst = ctOptmst (vSumt)^(1/(1-\[Rho]));
  \[CapitalLambda]tPesmst = ctPesmst (vSumt)^(1/(1-\[Rho]));
 (*
 \[ScriptV]tOptmstCon = u[\[Kappa]Maxt \[FilledUpTriangle]mt]+\[GothicV]OptmstCon0at; (* June 2012 KT fixed *)
  \[CapitalLambda]tOptmstCon =((1-\[Rho])\[ScriptV]tOptmstCon)^(1/(1-\[Rho]));
*)
(*  If[mt>=mCuspt
, *)\[CapitalChi]t  = \[CapitalChi]Hi[\[Mu]t, PeriodsUntilT]
; \[CapitalKoppa]t=1/(1+Exp[\[CapitalChi]t])
; \[CapitalLambda]tRealst=\[CapitalLambda]tOptmst- \[CapitalKoppa]t(\[CapitalLambda]tOptmst-\[CapitalLambda]tPesmst)
;
(*, \[CapitalChi]t  = \[CapitalChi]Lo[\[Mu]t, PeriodsUntilT]
; \[CapitalKoppa]t=1/(1+Exp[\[CapitalChi]t])
; \[CapitalLambda]tRealst=\[CapitalLambda]tOptmstCon- \[CapitalKoppa]t(\[CapitalLambda]tOptmstCon-\[CapitalLambda]tPesmst)
;
];*)
  Return[\[CapitalLambda]tRealst] 
];(*End Block*)


\[CapitalLambda]Lo[mt_,PeriodsUntilT_]:= Block[{
  mLowerBoundt, mHighestBelowmCuspt, mLowestAbovemCuspt, \[FilledUpTriangle]mt, \[FilledUpTriangle]\[GothicH]t, \[Kappa]t, \[Kappa]Maxt, \[Mu]t, \[CapitalChi]t, \[CapitalKoppa]t
, ctOptmst, ctPesmst, \[CapitalLambda]tTighterUpBd, \[CapitalLambda]tOptmst, \[CapitalLambda]tPesmst, \[CapitalLambda]tRealst, \[Mu]First, vSumt
, mCuspt, \[GothicV]OptmstCon0at, \[ScriptV]tOptmstCon, \[CapitalLambda]tOptmstCon},
  mLowerBoundt = mLowerBoundLife[[PeriodsUntilT+1]]; 
  mCuspt =mCuspLife[[PeriodsUntilT+1]];
  mHighestBelowmCuspt = mHighestBelowmCuspLife[[PeriodsUntilT+1]];
  mLowestAbovemCuspt = mLowestAbovemCuspLife[[PeriodsUntilT+1]]; 
(*
  \[GothicV]OptmstCon0at=\[GothicV]OptmstCon0aLife[[PeriodsUntilT+1]];
*)  vSumt =vSumLife[[PeriodsUntilT+1]];
  \[FilledUpTriangle]mt   = mt-mLowerBoundt;
  \[FilledUpTriangle]\[GothicH]t   = \[FilledUpTriangle]\[GothicH]AccessibleLife[[PeriodsUntilT+1]];
  \[Kappa]t    = \[Kappa]MinLife[[PeriodsUntilT+1]];
  \[Kappa]Maxt    = \[Kappa]MaxLife[[PeriodsUntilT+1]]; (* June 2012 KT added *)
  \[Mu]t = Log[\[FilledUpTriangle]mt];If[Chop[mt - mLowerBoundt]==0,\[Mu]t=-Infinity];
  ctOptmst = \[Kappa]t (\[FilledUpTriangle]mt+\[FilledUpTriangle]\[GothicH]t);
  ctPesmst = \[Kappa]t (\[FilledUpTriangle]mt); 
  \[CapitalLambda]tOptmst = \[CapitalLambda]\[Digamma]TighterUpBd[mt, PeriodsUntilT];
  \[CapitalLambda]tPesmst = ctPesmst (vSumt)^(1/(1-\[Rho]));
  (*
	\[ScriptV]tOptmstCon = u[\[Kappa]Maxt \[FilledUpTriangle]mt]+\[GothicV]OptmstCon0at; (* June 2012 KT fixed *)
  \[CapitalLambda]tOptmstCon =((1-\[Rho])\[ScriptV]tOptmstCon)^(1/(1-\[Rho]));
*)

(*  If[mt>=mCuspt
, \[CapitalChi]t  = \[CapitalChi]Hi[\[Mu]t, PeriodsUntilT]
; \[CapitalKoppa]t=1/(1+Exp[\[CapitalChi]t])
; \[CapitalLambda]tRealst=\[CapitalLambda]tOptmst- \[CapitalKoppa]t(\[CapitalLambda]tOptmst-\[CapitalLambda]tPesmst)
;
, *)\[CapitalChi]t  = \[CapitalChi]Lo[\[Mu]t, PeriodsUntilT]
; \[CapitalKoppa]t=1/(1+Exp[\[CapitalChi]t])
; \[CapitalLambda]tRealst=\[CapitalLambda]tOptmst- \[CapitalKoppa]t(\[CapitalLambda]tOptmst-\[CapitalLambda]tPesmst)
;
(*];*)
  Return[\[CapitalLambda]tRealst] 
];(*End Block*)



(*
\[CapitalLambda]\[Digamma]Md[mt_,PeriodsUntilT_]:= Block[{\[CapitalLambda]Val, vVal},
  If[PeriodsUntilT == 0
, (*then*)\[CapitalLambda]Val=mt
, (*else*)\[CapitalLambda]Val=\[CapitalLambda]FuncLifeMd[[PeriodsUntilT+1]][mt]
];
 Return[\[CapitalLambda]Val];
]; (* End Block[]*)

\[ScriptV]\[Digamma]Md[mt_,PeriodsUntilT_]:= Block[{\[CapitalLambda]Val, vVal},
  \[CapitalLambda]Val=\[CapitalLambda]\[Digamma]Md[mt, PeriodsUntilT];
  vVal=u[\[CapitalLambda]Val];
Return[vVal];
]; (* End Block[]*)
*)



\[CapitalLambda]Md[mt_,PeriodsUntilT_]:= Block[{
  \[CapitalLambda]tRealst},
	If[PeriodsUntilT == 0
, (*then*)\[CapitalLambda]tRealst=mt
, (*else*) \[CapitalLambda]tRealst = \[CapitalLambda]FuncLifeMd[[PeriodsUntilT+1]][mt];
];
  Return[\[CapitalLambda]tRealst];
];(*End Block*)

\[ScriptV]Hi[mt_,PeriodsUntilT_]:=u[\[CapitalLambda]Hi[mt,PeriodsUntilT]];
\[ScriptV]Lo[mt_,PeriodsUntilT_]:=u[\[CapitalLambda]Lo[mt,PeriodsUntilT]];
\[ScriptV]Md[mt_,PeriodsUntilT_]:=u[\[CapitalLambda]Md[mt,PeriodsUntilT]];


ClearAll[\[CapitalLambda], \[CapitalLambda]BeforeT, \[CapitalLambda]From\[CapitalChi]];
\[CapitalLambda][mt_,PeriodsUntilT_] := If[PeriodsUntilT==0,mt,(*else*)\[CapitalLambda]BeforeT[mt,PeriodsUntilT]];
\[CapitalLambda]BeforeT[mt_,PeriodsUntilT_]:= \[CapitalLambda]From\[CapitalChi][mt,PeriodsUntilT];

(*Block[{\[CapitalLambda]Unconstr,cUnconstr
, cWhereConstrBinds, vWhereConstrBinds, vConstr},
 If[Constrained==False, Return[\[CapitalLambda]From\[CapitalChi][mt,PeriodsUntilT]]];
  cUnconstr = \[ScriptC]From\[Chi][mt,PeriodsUntilT];
 If[cUnconstr > mt,
    cWhereConstrBinds = \[GothicC]FuncLife[[PeriodsUntilT+1]][0.];
    vWhereConstrBinds=u[\[CapitalLambda]From\[CapitalChi][cWhereConstrBinds,PeriodsUntilT]];
    vConstr = vWhereConstrBinds+u[mt]-u[cWhereConstrBinds]; (* Because MPC is 1 below point where constraint binds *)
    Return[((1-\[Rho])vConstr)^(1/(1-\[Rho]))]];
 Return[\[CapitalLambda]From\[CapitalChi][mt,PeriodsUntilT]];
];

*)
\[CapitalLambda]From\[CapitalChi][mt_,PeriodsUntilT_]:= Block[{
  mLowerBoundt, mCuspt, \[FilledUpTriangle]mt, mHighestBelowmCuspt 
, mLowestAbovemCuspt, \[FilledUpTriangle]\[GothicH]t, \[Kappa]t, \[Kappa]Maxt, \[Mu]t, \[CapitalChi]t, \[CapitalKoppa]t
, ctOptmst, ctPesmst, \[CapitalLambda]tTighterUpBd, \[CapitalLambda]tOptmst, \[CapitalLambda]tPesmst, \[CapitalLambda]tRealst, \[Mu]First, vSumt
, \[GothicV]OptmstCon0at, \[ScriptV]tOptmstTighterUpBd, \[CapitalLambda]tOptmstTighterUpBd},
  mLowerBoundt = \[GothicA]LowerBoundLife[[PeriodsUntilT+1]]; 
  mCuspt =mCuspLife[[PeriodsUntilT+1]];
  mHighestBelowmCuspt = mHighestBelowmCuspLife[[PeriodsUntilT+1]];
  mLowestAbovemCuspt = mLowestAbovemCuspLife[[PeriodsUntilT+1]]; 
  vSumt=vSumLife[[PeriodsUntilT+1]];
  \[FilledUpTriangle]mt   = mt-mLowerBoundt;
  \[FilledUpTriangle]\[GothicH]t   = \[FilledUpTriangle]\[GothicH]AccessibleLife[[PeriodsUntilT+1]];
  \[Kappa]t    = \[Kappa]MinLife[[PeriodsUntilT+1]];
  \[Kappa]Maxt    = \[Kappa]MaxLife[[PeriodsUntilT+1]]; (* June 2012 KT added *)
  \[Mu]t = Log[\[FilledUpTriangle]mt];If[Chop[mt - mLowerBoundt]==0,\[Mu]t=-Infinity];
  ctPesmst = \[Kappa]t (\[FilledUpTriangle]mt); 
  \[CapitalLambda]tPesmst = ctPesmst (vSumt)^(1/(1-\[Rho]));


  If[mt >= mLowestAbovemCuspt
(* if mt >= mLoestAbovemCuspt (lowest point above mCusp), use Hi func *)
, \[CapitalChi]t  = \[CapitalChi]Hi[\[Mu]t, PeriodsUntilT]
; \[CapitalKoppa]t=1/(1+Exp[\[CapitalChi]t])
; ctOptmst = \[Kappa]t (\[FilledUpTriangle]mt+\[FilledUpTriangle]\[GothicH]t)
; \[CapitalLambda]tOptmst = ctOptmst (vSumt)^(1/(1-\[Rho]))
; \[CapitalLambda]tRealst=\[CapitalLambda]tOptmst- \[CapitalKoppa]t(\[CapitalLambda]tOptmst-\[CapitalLambda]tPesmst)
;
];


(* if mHiestBelowmCuspt <= mt <mLowestAbovemCuspt , use Mid function *)
  If[And[mt < mLowestAbovemCuspt, mt >= mHighestBelowmCuspt]
(* then use Mid func *)
, \[CapitalLambda]tRealst = \[CapitalLambda]FuncLifeMd[[PeriodsUntilT+1]][mt]
];

(* if mt <= mHighestBelowmCuspt, use Lo func *)
 If[mt < mHighestBelowmCuspt
, \[CapitalChi]t  = \[CapitalChi]Lo[\[Mu]t, PeriodsUntilT]
; \[CapitalKoppa]t=1/(1+Exp[\[CapitalChi]t])
; \[ScriptV]tOptmst =  \[ScriptV]\[Digamma]TighterUpBd[mt,PeriodsUntilT]

; \[CapitalLambda]tOptmst =((1-\[Rho])\[ScriptV]tOptmst)^(1/(1-\[Rho])) 
; \[CapitalLambda]tRealst=\[CapitalLambda]tOptmst- \[CapitalKoppa]t(\[CapitalLambda]tOptmst-\[CapitalLambda]tPesmst)
;
]; 

  Return[\[CapitalLambda]tRealst];
];(*End Block*)


ClearAll[\[ScriptV]];
\[ScriptV][mt_,PeriodsUntilT_] := u[\[CapitalLambda][mt,PeriodsUntilT]];
\[ScriptV]Hi[mt_,PeriodsUntilT_]:=u[\[CapitalLambda]Hi[mt,PeriodsUntilT]];
\[ScriptV]Lo[mt_,PeriodsUntilT_]:=u[\[CapitalLambda]Lo[mt,PeriodsUntilT]];
\[ScriptV]Md[mt_,PeriodsUntilT_]:=u[\[CapitalLambda]Md[mt,PeriodsUntilT]];


(*
\[ScriptV][mt_,PeriodsUntilT_] := If[PeriodsUntilT==0,u[mt],(*else*)\[ScriptV]BeforeT[mt,PeriodsUntilT]];
\[ScriptV]BeforeT[mt_,PeriodsUntilT_] := \[ScriptV]From\[CapitalChi][mt,PeriodsUntilT];
\[ScriptV]From\[CapitalChi][mt_,PeriodsUntilT_] := u[\[CapitalLambda][mt,PeriodsUntilT]];
*)
\[ScriptV][mt_] := \[ScriptV][mt,Length[\[Beta]Life]-1]; (* Without lifeperiod argument, use most recently solved *)


ClearAll[\[ScriptV]m, \[ScriptV]mBeforeT];
\[ScriptV]m[mt_,PeriodsUntilT_] := If[PeriodsUntilT==0,uP[mt],(*else*)\[ScriptV]mBeforeT[mt,PeriodsUntilT]];
\[ScriptV]mBeforeT[mt_,PeriodsUntilT_] := uP[\[ScriptC][mt, PeriodsUntilT]];


(* ::Subsection:: *)
(*SetAttributes*)


SetAttributes[{
  \[Chi]Hi, \[Chi]Lo
, \[Chi]\[Mu]Hi, \[Chi]\[Mu]Lo
, \[ScriptC]Hi, \[ScriptC]Lo, \[ScriptC]Md
, \[ScriptC], \[ScriptC]BeforeT, \[ScriptC]From\[Chi]
, \[Kappa]Hi, \[Kappa]Lo, \[Kappa]Md
, \[Kappa], \[Kappa]BeforeT, \[Kappa]From\[Chi]

, \[CapitalChi]Hi, \[CapitalChi]Lo
, \[CapitalChi]\[Mu]Hi, \[CapitalChi]\[Mu]Lo
, \[CapitalLambda]Hi, \[CapitalLambda]Lo, \[CapitalLambda]Md
, \[CapitalLambda], \[CapitalLambda]BeforeT, \[CapitalLambda]From\[CapitalChi]
, \[ScriptV], \[ScriptV]BeforeT, \[ScriptV]From\[CapitalChi]

, \[ScriptV]m, \[ScriptV]mBeforeT}, Listable]; (* Allows funcs to operate on lists *)

