(* ::Package:: *)

(* 2periodIntExp.m *)

<<setup_everything.m;
\[GothicV]FuncLife = { 0. & };

<<prepareIntExp.m;
SolveAnotherPeriod;
