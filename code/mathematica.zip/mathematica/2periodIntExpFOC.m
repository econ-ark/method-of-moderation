(* ::Package:: *)

(* 2periodIntExpFOC.m *)
<<setup_everything.m;
\[GothicV]FuncLife  = { 0. & };
\[GothicV]aFuncLife = { 0. & };

<<prepareIntExpFOC.m;

SolveAnotherPeriod;
