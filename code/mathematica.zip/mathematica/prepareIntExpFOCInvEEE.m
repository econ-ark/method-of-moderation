(* ::Package:: *)

(* The solution method is identical to 2periodIntExpFOCInv.m;

 the only difference is the use of triple exponential grid *)

(* No function definitions are necessary *)

<<prepareIntExpFOCInv.m;
