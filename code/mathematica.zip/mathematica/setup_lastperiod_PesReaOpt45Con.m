(* ::Package:: *)

mStarLife = {Null}; 

c\[Sharp]t = m\[Sharp]t = 0.;
Constrained=True;
