(* ::Package:: *)

Print["Use the 'method of moderation' to solve constrained model.'"];
<<2periodIntExpFOCInvPesReaOpt45Con.m;                            

cTm1IntExpFOCInvPesReaOpt45Con = 
    Plot[{\[ScriptC][m, 1]},{m,0.,mMax}
    ,DisplayFunction->Identity
    ];

cTm1IntExpFOCInvPesReaOpt45 = 
    Plot[{\[ScriptC]From\[Chi][m,1]},{m,mVect[[1]],mMax}
    ,PlotStyle->{Dashing[{0.01}]}
    ,DisplayFunction->Identity
    ];

cVScCon = 
  Show[cTm1IntExpFOCInvPesReaOpt45Con,cTm1IntExpFOCInvPesReaOpt45
    ,DisplayFunction->$DisplayFunction
    ,AxesLabel->{"\!\(\*SubscriptBox[\(m\), \(T - 1\)]\)","\!\(\*SubscriptBox[\(c\), \(T - 1\)]\)"}
(*    ,PlotLabel->"Comparison of \[ScriptC]Tm1[m] with cTm1FOCInvCon[m]"*)
    ];
ExportFigs["cVScCon",cVScCon];
Print[cVScCon];









