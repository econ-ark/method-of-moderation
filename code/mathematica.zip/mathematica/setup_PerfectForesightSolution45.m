(* ::Package:: *)

(* Perfect foresight consumption function; \[Digamma] stands for 'foresight' *)


\[ScriptC]\[Digamma]45[mt_,PeriodsUntilT_]:=(mt-Min[\[Theta]Vals]+yMinPDV[[PeriodsUntilT+1]]);
\[ScriptV]\[Digamma]45[mt_,PeriodsUntilT_]:=u[\[ScriptC]\[Digamma]45[mt,PeriodsUntilT]]+\[GothicV]OptmstCon0aLife[[PeriodsUntilT+1]];
