(* ::Package:: *)

(* PeriodIntExpFOCInvPesReaOpt!Plot.m *)

<<2PeriodIntExpFOCInvPesReaOpt.m;
<<DefineTm1Raw.m;


mMaxPlot=mVect[[-1]]+1;
mMinPlot=-\[GothicH]MinLife[[-1]];
mGapPlot=mMaxPlot-mMinPlot;
mHalfPlot=mMinPlot+mGapPlot/2;
cHalft=\[ScriptC][mHalfPlot, 1];
Print["Use the 'method of moderation,' with only upper bound."];
(*
\[FilledUpTriangle]mCuspt=Last[\[Kappa]Min]*Last[\[FilledUpTriangle]\[GothicH]Life]/(1-Last[\[Kappa]Min]);
mCuspt=\[FilledUpTriangle]mCuspt-Last[\[GothicH]MinLife]; 
cCuspt=\[ScriptC][mCuspt, 1];
*)
cHalft=\[ScriptC][mHalft, 1];

(* Problem with the MoM: Needs 45 improvement *)
IntExpFOCInvPesReaOptNeedHiPlot = Show[
  Plot[{\[ScriptC][m, 1]
(*, \[ScriptC]\[Digamma]45[m, 1]*)
(*, \[ScriptC]\[Digamma][m,1]*)
, \[ScriptC]\[Digamma]Pes[m,1]}
, {m, -\[GothicH]MinLife[[-1]], mMaxPlot}
, AxesLabel->{"\!\(\*SubscriptBox[\(m\), \(T - 1\)]\)","\!\(\*SubscriptBox[\(c\), \(T - 1\)]\)"}
, PlotStyle->{
  Directive[Black,Thickness[Small]]
, Directive[Black,Thickness[Medium]]
, Directive[Black,Thickness[Large]]
}
, PlotRange->{{-\[GothicH]MinLife[[-1]], mMaxPlot}, {0, \[ScriptC]\[Digamma][mMaxPlot, 1]}}
]
(*, Plot[\[ScriptC]\[Digamma]45[m, 1]
, {m, -\[GothicH]MinLife[[-1]], mCuspt}
, PlotStyle->{
      Directive[Black,Thickness[Medium]]}]
*)
, Plot[\[ScriptC]\[Digamma][m,1]
, {m, -\[GothicH]MinLife[[-1]],mMaxPlot}
, PlotStyle->{
      Directive[Black,Thickness[Medium]]}]
, ListPlot[Transpose[{mVect, cVectRealst}]]
(*, ListPlot[{{mCuspt, cCuspt}}, PlotMarkers->{"\[SmallCircle]", Large}, PlotStyle->PointSize[0.02]]
, Graphics[{Dashed, Line[{{mCuspt, 0.0},{mCuspt, 1.2}}]}]
, Graphics[{Text["\[LowerLeftArrow]\!\(\*SuperscriptBox[\(m\), \(\[Sharp]\)]\)", {mCuspt*1.12, 0.05}]}]
, Graphics[{Text["\[LeftArrow]\!\(\*OverscriptBox[\(c\), \(_\)]\)=\[FilledUpTriangle]m", {mCuspt*1.62, 1.17}]}]*)
, Graphics[{Text["\!\(\*OverscriptBox[\(c\), \(_\)]\)=(\[FilledUpTriangle]m+\[FilledUpTriangle]\[GothicH])\[Kappa]\[LongRightArrow] ", {mMinPlot+(mGapPlot/2),\[ScriptC]\[Digamma][mMinPlot+(mGapPlot/2),1]},{1,0}]}]
, Graphics[{Text["\!\(\*OverscriptBox[\(c\), \(`\)]\)\[LongRightArrow]",  {mMinPlot+(mGapPlot 5/6),\[ScriptC][mMinPlot+(mGapPlot 5/6),1]},{1,0}]}]
, Graphics[{Text[" \[LongLeftArrow]\!\(\*UnderscriptBox[\(c\), \(_\)]\)=(\[FilledUpTriangle]m)\[Kappa]",{mMinPlot+(mGapPlot/2),\[ScriptC]\[Digamma]Pes[mMinPlot+(mGapPlot/2),1]},{-1,0}]}]
];
ExportFigs["IntExpFOCInvPesReaOptNeedHiPlot", IntExpFOCInvPesReaOptNeedHiPlot];
Print[IntExpFOCInvPesReaOptNeedHiPlot];


IntExpFOCInvPesReaOptNeedHiValuePlot = Show[
  Plot[{\[ScriptV][m, 1]
(*, \[ScriptV]\[Digamma]45[m,1]*)
, \[ScriptV]\[Digamma][m,1]
, \[ScriptV]\[Digamma]Pes[m,1]}
, {m, -\[GothicH]MinLife[[-1]], 2}
, AxesLabel->{"\!\(\*SubscriptBox[\(m\), \(T - 1\)]\)", "\!\(\*SubscriptBox[\(\[ScriptV]\), \(T - 1\)]\)"}
, PlotStyle->{
  Directive[Black,Thickness[Small]]
, Directive[Black,Thickness[Medium],Dashing[Medium]]
, Directive[Black,Thickness[Medium],Dashing[Tiny]]
, Directive[Black,Thickness[Medium]]
}
, AxesOrigin->{0, -1.2}
, PlotRange->{{-\[GothicH]MinLife[[-1]], 2}, {-6, -1.2}}
]
(*, Plot[\[ScriptV]\[Digamma]45[m,1]
, {m, -\[GothicH]MinLife[[-1]], mHalfPlot}
, PlotStyle->{Directive[Black,Thickness[Medium]]}]*)
, Plot[\[ScriptV]\[Digamma][m,1]
, {m, mHalfPlot, 2}
, PlotStyle->{
      Directive[Black,Thickness[Medium]]}]
, ListPlot[Most[Transpose[{mVect, cVectRealst}]]]
, ListPlot[{{mHalfPlot, cHalft}}, PlotMarkers->{"\[SmallCircle]", Large}, PlotStyle->PointSize[0.02]]
, Graphics[{Dashed, Line[{{mHalfPlot, 0.0},{mHalfPlot, -10}}]}]
, Graphics[{Text["\[UpperLeftArrow]\!\(\*SuperscriptBox[\(m\), \(\[Sharp]\)]\)", {mHalfPlot*1.12, -1.45}]}]
];
ExportFigs["IntExpFOCInvPesReaOptNeedHiValuePlot", IntExpFOCInvPesReaOptNeedHiValuePlot];


(*Print["Difference in consumption function before and after refinement."];

IntExpFOCInvPesReaOptHiGapPlot = Show[Plot[{\[ScriptC]Hi[m, 1]-\[ScriptC]Lo[m, 1]}
,{m,mVect[[1]],1}
,AxesLabel->{"\!\(\*SubscriptBox[\(m\), \(T - 1\)]\)"
, "\!\(\*SubsuperscriptBox[OverscriptBox[\(c\), \(`\)], \(H, T - 1\), \(\[Chi]\)]\)-\!\(\*SubsuperscriptBox[OverscriptBox[\(c\), \(`\)], \(L, T - 1\), \(\[Chi]\)]\)"}
, PlotRange->{{mVect[[1]], mHalfPlot+0.2},{0.0001, -0.0001}}]
, Graphics[{Dashed, Line[{{mHalfPlot,0.05},{mHalfPlot,-0.05}}]}]
, Graphics[{Text["\[LowerLeftArrow]\!\(\*SuperscriptBox[\(m\), \(\[DoubleDagger]\)]\)", {mHalfPlot*1.05, 0.00001}]}]
];

ExportFigs["IntExpFOCInvPesReaOptHiGapPlot",IntExpFOCInvPesReaOptHiGapPlot];
Print[IntExpFOCInvPesReaOptHiGapPlot];
*)


(*
IntExpFOCInvPesReaOptHiValueGapPlot = Show[Plot[{\[ScriptV]Hi[m, 1]-\[ScriptV]Lo[m, 1]}
, {m,mVect[[1]],1}
, AxesLabel->{"\!\(\*SubscriptBox[\(m\), \(T - 1\)]\)"
, "\!\(\*SubsuperscriptBox[OverscriptBox[\(\[ScriptV]\), \(`\)], \(H, T - 1\), \(\[Chi]\)]\)-\!\(\*SubsuperscriptBox[OverscriptBox[\(\[ScriptV]\), \(`\)], \(L, T - 1\), \(\[Chi]\)]\)"}
, PlotRange->{{mVect[[1]], mHalfPlot+0.2},{0.02, -0.01}}]
, Graphics[{Dashed, Line[{{mHalfPlot,0.05},{mHalfPlot,-0.05}}]}]
, Graphics[{Text["\!\(\*SuperscriptBox[\(m\), \(\[DoubleDagger]\)]\)\[LowerRightArrow]", {mHalfPlot*0.95, 0.0010}]}]
];

ExportFigs["IntExpFOCInvPesReaOptHiValueGapPlot",IntExpFOCInvPesReaOptHiValueGapPlot];
Print[IntExpFOCInvPesReaOptHiValueGapPlot];


*)






