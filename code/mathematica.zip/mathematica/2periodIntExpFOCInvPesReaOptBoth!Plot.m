(* ::Package:: *)

(* PeriodIntExpFOCInvPesReaOpt!Plot.m *)

<<2PeriodIntExpFOCInvPesReaOptBoth.m;
<<DefineTm1Raw.m;


Print["Use the 'method of moderation, with both upper and lower bounds.'"];
\[FilledUpTriangle]mCuspt=Last[\[Kappa]Min]*Last[\[FilledUpTriangle]\[GothicH]Life]/(1-Last[\[Kappa]Min]);
mCuspt=\[FilledUpTriangle]mCuspt-Last[\[GothicH]MinLife]; 
cCuspt=\[ScriptC][mCuspt, 1];

(* Problem with the MoM: Needs 45 improvement *)
IntExpFOCInvPesReaOptNeedBothPlot = Show[
  Plot[{\[ScriptC][m, 1]
, \[ScriptC]\[Digamma]45[m, 1]
, \[ScriptC]\[Digamma][m,1]
, \[ScriptC]\[Digamma]Pes[m,1]}
, {m, -\[GothicH]MinLife[[-1]], 2}
, AxesLabel->{"\!\(\*SubscriptBox[\(m\), \(T - 1\)]\)","\!\(\*SubscriptBox[\(c\), \(T - 1\)]\)"}
, PlotStyle->{
  Directive[Black,Thickness[Small]]
, Directive[Black,Thickness[Medium],Dashing[Medium]]
, Directive[Black,Thickness[Medium],Dashing[Tiny]]
, Directive[Black,Thickness[Medium]]
}
, PlotRange->{{-\[GothicH]MinLife[[-1]], 2}, {0, 1.2}}
]
, Plot[\[ScriptC]\[Digamma]45[m, 1]
, {m, -\[GothicH]MinLife[[-1]], mCuspt}
, PlotStyle->{
      Directive[Black,Thickness[Medium]]}]
, Plot[\[ScriptC]\[Digamma][m,1]
, {m, mCuspt, 2}
, PlotStyle->{
      Directive[Black,Thickness[Medium]]}]
, ListPlot[Most[Transpose[{mVect, cVectRealst}]]]
, ListPlot[{{mCuspt, cCuspt}}, PlotMarkers->{"\[SmallCircle]", Large}, PlotStyle->PointSize[0.02]]
, Graphics[{Dashed, Line[{{mCuspt, 0.0},{mCuspt, 1.2}}]}]
, Graphics[{Text["\[LowerLeftArrow]\!\(\*SuperscriptBox[\(m\), \(\[Sharp]\)]\)", {mCuspt*1.12, 0.05}]}]
, Graphics[{Text["\[LeftArrow]\!\(\*OverscriptBox[\(c\), \(_\)]\)=\[FilledUpTriangle]m", {mCuspt*1.62, 1.17}]}]
, Graphics[{Text["\[LeftArrow]\!\(\*OverscriptBox[\(c\), \(_\)]\)=\[Kappa](\[FilledUpTriangle]m+\[FilledUpTriangle]\[GothicH])", {mCuspt*1.5, 0.92}]}]
, Graphics[{Text["\[LeftArrow]\!\(\*c\)", {mCuspt*1.23, 0.615}]}]
, Graphics[{Text["\[LeftArrow]\!\(\*OverscriptBox[\(c\), \(_\)]\)=\[Kappa](\[FilledUpTriangle]m)", {mCuspt*1.35, 0.46}]}]
];
ExportFigs["IntExpFOCInvPesReaOptNeedBothPlot", IntExpFOCInvPesReaOptNeedBothPlot];
Print[IntExpFOCInvPesReaOptNeedBothPlot];


IntExpFOCInvPesReaOptNeedBothValuePlot = Show[
  Plot[{\[ScriptV][m, 1]
, \[ScriptV]\[Digamma]45[m,1]
, \[ScriptV]\[Digamma][m,1]
, \[ScriptV]\[Digamma]Pes[m,1]}
, {m, -\[GothicH]MinLife[[-1]], 2}
, AxesLabel->{"\!\(\*SubscriptBox[\(m\), \(T - 1\)]\)", "\!\(\*SubscriptBox[\(\[ScriptV]\), \(T - 1\)]\)"}
, PlotStyle->{
  Directive[Black,Thickness[Small]]
, Directive[Black,Thickness[Medium],Dashing[Medium]]
, Directive[Black,Thickness[Medium],Dashing[Tiny]]
, Directive[Black,Thickness[Medium]]
}
, AxesOrigin->{0, -1.2}
, PlotRange->{{-\[GothicH]MinLife[[-1]], 2}, {-6, -1.2}}
]
, Plot[\[ScriptV]\[Digamma]45[m,1]
, {m, -\[GothicH]MinLife[[-1]], mCuspt}
, PlotStyle->{Directive[Black,Thickness[Medium]]}]
, Plot[\[ScriptV]\[Digamma][m,1]
, {m, mCuspt, 2}
, PlotStyle->{
      Directive[Black,Thickness[Medium]]}]
, ListPlot[Most[Transpose[{mVect, cVectRealst}]]]
, ListPlot[{{mCuspt, cCuspt}}, PlotMarkers->{"\[SmallCircle]", Large}, PlotStyle->PointSize[0.02]]
, Graphics[{Dashed, Line[{{mCuspt, 0.0},{mCuspt, -10}}]}]
, Graphics[{Text["\[UpperLeftArrow]\!\(\*SuperscriptBox[\(m\), \(\[Sharp]\)]\)", {mCuspt*1.12, -1.45}]}]
];
ExportFigs["IntExpFOCInvPesReaOptNeedBothValuePlot", IntExpFOCInvPesReaOptNeedBothValuePlot];
Print[IntExpFOCInvPesReaOptNeedBothValuePlot];


Print["Difference in consumption function before and after refinement."];

IntExpFOCInvPesReaOptBothGapPlot = Show[Plot[{\[ScriptC]Hi[m, 1]-\[ScriptC]Lo[m, 1]}
,{m,mVect[[1]],1}
,AxesLabel->{"\!\(\*SubscriptBox[\(m\), \(T - 1\)]\)", "\!\(\*SubscriptBox[OverscriptBox[OverscriptBox[\(c\), \(^\)], \(`\)], \(T - 1\)]\)-\!\(\*SubscriptBox[OverscriptBox[OverscriptBox[\(c\), \(\[Hacek]\)], \(`\)], \(T - 1\)]\)"}
, PlotRange->{{mVect[[1]], mCuspt+0.2},{0.0001, -0.0001}}]
, Graphics[{Dashed, Line[{{mCuspt,0.05},{mCuspt,-0.05}}]}]
, Graphics[{Text["\[LowerLeftArrow]\!\(\*SuperscriptBox[\(m\), \(\[Sharp]\)]\)", {mCuspt*1.05, 0.00001}]}]
];

ExportFigs["IntExpFOCInvPesReaOptBothGapPlot",IntExpFOCInvPesReaOptBothGapPlot];
Print[IntExpFOCInvPesReaOptBothGapPlot];


IntExpFOCInvPesReaOptBothValueGapPlot = Show[Plot[{\[ScriptV]Hi[m, 1]-\[ScriptV]Lo[m, 1]}
, {m,mVect[[1]],1}
, AxesLabel->{"\!\(\*SubscriptBox[\(m\), \(T - 1\)]\)"
, "\!\(\*SubscriptBox[OverscriptBox[OverscriptBox[\(\[GothicV]\), \(^\)], \(`\)], \(T - 1\)]\)-\!\(\*SubscriptBox[OverscriptBox[OverscriptBox[\(\[GothicV]\), \(\[Hacek]\)], \(`\)], \(T - 1\)]\)"}
, PlotRange->{{mVect[[1]], mCuspt+0.2},{0.02, -0.01}}]
, Graphics[{Dashed, Line[{{mCuspt,0.05},{mCuspt,-0.05}}]}]
, Graphics[{Text["\!\(\*SuperscriptBox[\(m\), \(\[Sharp]\)]\)\[LowerRightArrow]", {mCuspt*0.95, 0.0010}]}]
];

ExportFigs["IntExpFOCInvPesReaOptBothValueGapPlot",IntExpFOCInvPesReaOptBothValueGapPlot];
Print[IntExpFOCInvPesReaOptBothValueGapPlot];
