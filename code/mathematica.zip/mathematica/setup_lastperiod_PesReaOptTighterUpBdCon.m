(* ::Package:: *)

mStarLife = {Null}; 
cStarLife = {Null}; 
aStarLife = {Null}; 
\[GothicV]StarLife = {Null}; 
\[ScriptV]StarLife = {Null}; 
\[CapitalLambda]StarLife = {Null};
