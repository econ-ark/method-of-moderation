(* ::Package:: *)

\[FilledUpTriangle]mCuspLife = {Null};
mCuspLife = {Null}; 
\[GothicV]OptmstCon0aLife ={0};

\[Koppa]FuncLifeHi = { Indeterminate & }; (* Not well defined in last period *)
\[Chi]FuncLifeHi = { Indeterminate & }; (* Not well defined in last period *)
\[CapitalKoppa]FuncLifeHi = { Indeterminate & }; (* Not well defined in last period *)
\[CapitalChi]FuncLifeHi = { Indeterminate & }; (* Not well defined in last period *)
\[CapitalLambda]FuncLifeHi = { Indeterminate & }; (* Not well defined in last period *)

\[Koppa]FuncLifeLo = { Indeterminate & }; (* Not well defined in last period *)
\[Chi]FuncLifeLo = { Indeterminate & }; (* Not well defined in last period *)
\[CapitalKoppa]FuncLifeLo = { Indeterminate & }; (* Not well defined in last period *)
\[CapitalChi]FuncLifeLo = { Indeterminate & }; (* Not well defined in last period *)
\[CapitalLambda]FuncLifeLo = { Indeterminate & }; (* Not well defined in last period *)
