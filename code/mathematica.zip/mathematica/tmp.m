(* ::Package:: *)

Subscript[
\!\(\*OverscriptBox[
OverscriptBox[\(c\), \(^\)], \(`\)]\), T-1],Subscript[
\!\(\*OverscriptBox[
OverscriptBox[\(c\), \(\[Hacek]\)], \(`\)]\), T-1]
Subscript[
\!\(\*OverscriptBox[
OverscriptBox[\(\[GothicV]\), \(^\)], \(`\)]\), T-1],Subscript[
\!\(\*OverscriptBox[
OverscriptBox[\(\[GothicV]\), \(\[Hacek]\)], \(`\)]\), T-1]
