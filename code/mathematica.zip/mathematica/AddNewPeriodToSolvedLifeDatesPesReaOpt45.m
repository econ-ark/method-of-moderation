(* ::Package:: *)

(* AddNewPeriodToSolvedLifeDatesPesReaOpt45 *)
ClearAll[AddNewPeriodToSolvedLifeDatesPesReaOpt45];

AddNewPeriodToSolvedLifeDatesPesReaOpt45 := Block[{},
(* Use insight that Pesmst < Realst < 45 Degree Line for c *)
 
  AppendTo[\[Chi]FuncLifeHi, \[Chi]Func];
  AppendTo[\[CapitalChi]FuncLifeHi, \[CapitalChi]Func];
  \[GothicH]Expt   =  Last[\[GothicH]ExpLife];
  \[GothicH]Mint   =  Last[\[GothicH]MinLife];
  \[FilledUpTriangle]mCuspt =  Last[\[FilledUpTriangle]mCuspLife];
  mCuspt =  Last[mCuspLife];

(* Values for different variables at the cusp point are all calculated *)
  cCuspt  = \[ScriptC]From\[Chi][mCuspt, PeriodsSolved+1];
  \[GothicA]Cuspt  = mCuspt - cCuspt;
  \[Kappa]Cuspt = \[Kappa]From\[Chi][mCuspt, PeriodsSolved+1];

  vCuspt = \[ScriptV]From\[CapitalChi][mCuspt, PeriodsSolved+1];
  \[Mu]Cuspt = Log[\[FilledUpTriangle]mCuspt];

(* Divide gridpoins into lower and higher part of the cusp point *)
(* Both the higher and the lower part include the cusp point *)
  mVectLo    = Union[Select[mVect, # <= mCuspt &],{mCuspt}];
  \[FilledUpTriangle]mVectLo   =  mVectLo-mLowerBoundt;
  \[Mu]VectLo    = Append[\[Mu]Vect[[1;;Length[mVectLo]-1]], \[Mu]Cuspt];
  cVectLo    = Append[cVect[[1;;Length[mVectLo]-1]], cCuspt];

  \[Kappa]VectLo    = Append[\[Kappa]Vect[[1;;Length[mVectLo]-1]], \[Kappa]Cuspt];
  vVectLo    = Append[vVect[[1;;Length[mVectLo]-1]], vCuspt];

  cVectRealstLo = cVectLo;   (* Realst's solution already obtained in AddNewPeriodToSolvedLifeDates  *)
  cVectOptmstLo = \[FilledUpTriangle]mVectLo;  (* Optimst *)
  (* For m>mCusp, we have cVectOptmst = \[Kappa]t (\[FilledUpTriangle]mVect+\[FilledUpTriangle]\[GothicH]t); (* Optimst *)*)
  cVectPesmstLo = \[Kappa]t \[FilledUpTriangle]mVectLo;  (* Pessimist *)
  \[Kappa]VectRealstLo = \[Kappa]VectLo;

  \[Koppa]ValsLo  = (cVectOptmstLo-cVectRealstLo)/(cVectOptmstLo-cVectPesmstLo);
  \[Koppa]\[Mu]ValsLo = (cVectRealstLo-\[Kappa]VectRealstLo*\[FilledUpTriangle]mVectLo)/\[FilledUpTriangle]mVectLo/(1-\[Kappa]t);

  \[Chi]ValsLo  = Log[(1/\[Koppa]ValsLo)-1];
  \[Chi]\[Mu]ValsLo = \[Koppa]\[Mu]ValsLo/((\[Koppa]ValsLo-1) \[Koppa]ValsLo);  (* Derivative of \[Chi] wrt \[Mu] *)
  \[Chi]DataLo=Transpose[{AddBracesTo[\[Mu]VectLo],\[Chi]ValsLo,\[Chi]\[Mu]ValsLo}];

  {\[Mu]BotLo, \[Mu]TopLo  } = {\[Mu]VectLo[[1]] ,\[Mu]VectLo[[-1]]};
  {\[Chi]BotLo, \[Chi]TopLo  } = {\[Chi]ValsLo[[1]] ,\[Chi]ValsLo[[-1]]};
  {\[Chi]\[Mu]BotLo, \[Chi]\[Mu]TopLo} = {\[Chi]\[Mu]ValsLo[[1]],\[Chi]\[Mu]ValsLo[[-1]]};
  \[Chi]FuncLo := Evaluate[(* Evaluate forces computation and storage of actual numbers for \[Mu]Bot etc *) 
    (Piecewise[{
      {\[Chi]BotLo+\[Chi]\[Mu]BotLo(#-\[Mu]BotLo)      , #    <= \[Mu]BotLo        }
     ,{Interpolation[\[Chi]DataLo][#] , \[Mu]BotLo <  #   < \[Mu]TopLo }
     ,{\[Chi]TopLo+\[Chi]\[Mu]TopLo(#-\[Mu]TopLo)      ,         \[Mu]TopLo <= #   }
    }])]&;
  AppendTo[\[Chi]FuncLifeLo, \[Chi]FuncLo];

(** Value function approximation **)

  cOptmstCuspt    = \[FilledUpTriangle]mCuspt;
  vOptmstCuspt    = u[cOptmstCuspt]*\[DoubleStruckCapitalC]t;
  \[GothicV]OptmstCon0at  = u[cOptmstCuspt]*(\[DoubleStruckCapitalC]t-1); (* \[GothicV] means end of period value. *)
  AppendTo[\[GothicV]OptmstCon0aLife, \[GothicV]OptmstCon0at];

  vVectOptmstLo = u[\[FilledUpTriangle]mVectLo]+\[GothicV]OptmstCon0at;
  vVectRealstLo = vVectLo;
  vVectPesmstLo = u[cVectPesmstLo]*\[DoubleStruckCapitalC]t;

  vmVectOptmstLo = uP[cVectOptmstLo];
  vmVectRealstLo = uP[cVectRealstLo]; (* Using Envelope relation uP[c]=vm[m] *)

  \[CapitalLambda]VectOptmstLo = ((1-\[Rho])vVectOptmstLo)^(1/(1-\[Rho]));
  \[CapitalLambda]VectRealstLo = ((1-\[Rho])vVectRealstLo)^(1/(1-\[Rho]));
  \[CapitalLambda]VectPesmstLo = ((1-\[Rho])vVectPesmstLo)^(1/(1-\[Rho]));

  \[CapitalLambda]mVectOptmstLo = ((1-\[Rho])vVectOptmstLo)^(-1+1/(1-\[Rho]))vmVectOptmstLo;
  \[CapitalLambda]mVectRealstLo = ((1-\[Rho])vVectRealstLo)^(-1+1/(1-\[Rho]))vmVectRealstLo;
  \[CapitalLambda]mVectPesmstLo = Table[\[Kappa]t, {i, 1, Length[mVectLo]}]*(\[DoubleStruckCapitalC]t)^(1/(1-\[Rho]));

  \[CapitalKoppa]ValsLo = (\[CapitalLambda]VectOptmstLo - \[CapitalLambda]VectRealstLo)/(\[CapitalLambda]VectOptmstLo-\[CapitalLambda]VectPesmstLo);
  \[CapitalKoppa]\[Mu]ValsLo = \[FilledUpTriangle]mVectLo ((\[CapitalLambda]mVectOptmstLo - \[CapitalLambda]mVectRealstLo)-\[CapitalKoppa]ValsLo(\[CapitalLambda]mVectOptmstLo - \[CapitalLambda]mVectPesmstLo))/(\[CapitalLambda]VectOptmstLo-\[CapitalLambda]VectPesmstLo);

  \[CapitalChi]ValsLo = Log[(1/\[CapitalKoppa]ValsLo)-1];
  \[CapitalChi]\[Mu]ValsLo = \[CapitalKoppa]\[Mu]ValsLo/((\[CapitalKoppa]ValsLo-1) \[CapitalKoppa]ValsLo);  (* Derivative of \[CapitalChi] wrt \[Mu] *)
  \[CapitalChi]DataLo=Transpose[{AddBracesTo[\[Mu]VectLo], \[CapitalChi]ValsLo, \[CapitalChi]\[Mu]ValsLo}];

  AppendTo[\[CapitalKoppa]FuncLifeLo,Interpolation[\[CapitalKoppa]DataLo=Transpose[{AddBracesTo[\[Mu]VectLo], \[CapitalKoppa]ValsLo, \[CapitalKoppa]\[Mu]ValsLo}]]];
  {\[CapitalChi]BotLo, \[CapitalChi]TopLo} = {\[CapitalChi]ValsLo[[1]], \[CapitalChi]ValsLo[[-1]]};
  {\[CapitalChi]\[Mu]BotLo, \[CapitalChi]\[Mu]TopLo} = {\[CapitalChi]\[Mu]ValsLo[[1]], \[CapitalChi]\[Mu]ValsLo[[-1]]};
  \[CapitalChi]FuncLo := Evaluate[(Piecewise[{
    {\[CapitalChi]BotLo+\[CapitalChi]\[Mu]BotLo(#-\[Mu]Bot)      , #    <=  \[Mu]BotLo       }
   ,{Interpolation[\[CapitalChi]DataLo][#]   ,   \[Mu]BotLo < #      < \[Mu]TopLo}
   ,{\[CapitalChi]TopLo+\[CapitalChi]\[Mu]TopLo(#-\[Mu]TopLo)    ,      \[Mu]TopLo   <= #  }
  }])]&;
  AppendTo[\[CapitalChi]FuncLifeLo,\[CapitalChi]FuncLo];

  AppendTo[\[CapitalLambda]FuncLifeLo,Interpolation[\[CapitalLambda]DataLo=Transpose[{AddBracesTo[mVectLo]
, \[CapitalLambda]VectRealstLo}],InterpolationOrder->1]];

];
