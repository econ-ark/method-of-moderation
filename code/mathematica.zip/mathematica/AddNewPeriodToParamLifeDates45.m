(* ::Package:: *)

ClearAll[AddNewPeriodToParamLifeDates45];

AddNewPeriodToParamLifeDates45 := Block[{},

(* The point where 45 degree line intersects with the optimst solution *)
AppendTo[\[FilledUpTriangle]mCuspLife, Last[\[Kappa]Min]*Last[\[FilledUpTriangle]\[GothicH]Life]/(1-Last[\[Kappa]Min])];
AppendTo[mCuspLife, Last[\[FilledUpTriangle]mCuspLife]-Last[\[GothicH]MinLife]]; 
];
