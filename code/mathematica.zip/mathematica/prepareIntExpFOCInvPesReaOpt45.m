(* ::Package:: *)

(* prepareIntExpFOCInvPesReaOpt45.m *)

<<functions_stable.m;
<<functions_PesReaOpt45.m;
<<AddNewPeriodToParamLifeDates.m;
<<AddNewPeriodToParamLifeDates45.m;
<<AddNewPeriodToSolvedLifeDates.m;
<<AddNewPeriodToSolvedLifeDatesPesReaOpt.m;
<<AddNewPeriodToSolvedLifeDatesPesReaOpt45.m;


SolveAnotherPeriod := Block[{},

  AddNewPeriodToParamLifeDates;
  AddNewPeriodToParamLifeDates45;
  AppendTo[\[GothicA]LowerBoundLife,\[GothicA]LowerBoundt=-Last[\[GothicH]MinLife]];
  AppendTo[mLowerBoundLife,mLowerBoundt=-Last[\[GothicH]MinLife]];
(*Unconstrained consumer can borrow against certain future income*)
  AddNewPeriodToSolvedLifeDates;
  AddNewPeriodToSolvedLifeDatesPesReaOpt;  
  AddNewPeriodToSolvedLifeDatesPesReaOpt45;
  PeriodsSolved++
];
