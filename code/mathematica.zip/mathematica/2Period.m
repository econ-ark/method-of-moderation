(* ::Package:: *)

(* 2Period.m *)
<<setup_everything.m;
<<prepare.m;

(* Until now, 1 period has been solved (the last), 'another' makes it 2 *)
SolveAnotherPeriod;
