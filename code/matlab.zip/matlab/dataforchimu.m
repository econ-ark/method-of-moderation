
MM_chiIntData;
  chiIntData(:,1,2:21)= reshape(M_chiIntData(:,1),6,1,20);
  chiIntData(:,2,2:21)= reshape(M_chiIntData(:,2),6,1,20);
  chiIntData(:,3,2:21)= reshape(M_chiIntData(:,3),6,1,20);