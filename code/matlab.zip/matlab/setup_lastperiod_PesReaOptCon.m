%==========================================================================%
% Solution Methods for Micro Dymanic Stochastic Optimization               %
%                                                                          %
% setup_lastperiod_PesReaOptCon.m                                          %
% 	Sets the extra values needed for the constrained multi period problem. %
%                                                                          %
%__________________________________________________________________________%
mt = 0;
Constrained = 1;