This directory contains all of the files necessary for reproducing the figures up to the structural estimation section 
in the lecture notes for Solution Methods for Micro Dymanic Stochastic Optimization in Matlab.

To plot all figures use 'doall.m'.

The files replicate the work done by the equivalent Mathematica notebook.