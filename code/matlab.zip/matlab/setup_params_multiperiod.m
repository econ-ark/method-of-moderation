%==========================================================================%
% Solution Methods for Micro Dymanic Stochastic Optimization               %
%                                                                          %
% setup_params_multiperiod.m                                               %
%	Changes the value of the standard deviation of the shock points.       %
%                                                                          %
%__________________________________________________________________________%

Sigma = 0.2;